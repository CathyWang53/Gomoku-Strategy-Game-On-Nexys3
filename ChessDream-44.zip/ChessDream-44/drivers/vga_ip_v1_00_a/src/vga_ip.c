/*****************************************************************************
* Filename:          E:\Xilinx\EDKprojects\lab_vga/drivers/vga_ip_v1_00_a/src/vga_ip.c
* Version:           1.00.a
* Description:       vga_ip Driver Source File
* Date:              Sat Dec 01 11:20:07 2012 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "vga_ip.h"

/************************** Function Definitions ***************************/

